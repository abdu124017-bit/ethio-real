const products = [{"name": "ኮንክሪት ሚስማር", "category": "construction", "description": "በተለያዩ መጠኖች • በካርቶን/በብዛት", "symbol": "🔩"}, {"name": "መለኪያ ቴፕ", "category": "construction", "description": "3m እና 5m • የተለያዩ ዓይነቶች", "symbol": "📏"}, {"name": "ማስቲክ", "category": "construction", "description": "የተለያዩ መጠኖችና ዓይነቶች", "symbol": "🧰"}, {"name": "ብሩሽ", "category": "construction", "description": "የተለያዩ ቁጥሮችና ዓይነቶች", "symbol": "🖌️"}, {"name": "PPR ኤልቦ", "category": "plumbing", "description": "የቧንቧ መገጣጠሚያ እቃዎች", "symbol": "🚰"}, {"name": "HDPE ቧንቧ እና ኤልቦ", "category": "plumbing", "description": "½፣ ¾ እና 1 ኢንች መጠኖች", "symbol": "〰️"}, {"name": "GS ቧንቧ", "category": "plumbing", "description": "የተለያዩ መጠኖች", "symbol": "🪠"}, {"name": "Union / Teflon / Reducer", "category": "plumbing", "description": "የቧንቧ መገጣጠሚያ እቃዎች", "symbol": "🔧"}, {"name": "LED መብራቶች", "category": "electric", "description": "የተለያዩ ዓይነቶችና መጠኖች", "symbol": "💡"}, {"name": "ገመድ / ኬብል", "category": "electric", "description": "የኤሌክትሪክ ገመዶች", "symbol": "🔌"}, {"name": "ሶኬት / ስዊች", "category": "electric", "description": "የቤትና የህንፃ ኤሌክትሪክ እቃዎች", "symbol": "🔘"}, {"name": "Profile / Flood / Pendant Light", "category": "electric", "description": "የተለያዩ የመብራት ዓይነቶች", "symbol": "✨"}];

const grid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const emptyMessage = document.getElementById("emptyMessage");
let activeFilter = "all";

function orderLink(productName) {
  const message = `ሰላም ETHIO REAL፣ ${productName} ለማዘዝ እፈልጋለሁ። ዋጋና ዝርዝር መረጃ ይላኩልኝ።`;
  return `https://wa.me/251976213646?text=${encodeURIComponent(message)}`;
}

function renderProducts() {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const filtered = products.filter(p => {
    const matchesCategory = activeFilter === "all" || p.category === activeFilter;
    const matchesSearch = `${p.name} ${p.description}`.toLocaleLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });
  grid.innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-symbol" aria-hidden="true">${p.symbol}</div>
      <h3>${p.name}</h3>
      <p>${p.description}</p>
      <a class="order-link" href="${orderLink(p.name)}" target="_blank" rel="noopener">ዋጋ ይጠይቁ / ይዘዙ ↗</a>
    </article>`).join("");
  emptyMessage.hidden = filtered.length !== 0;
}

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    activeFilter = button.dataset.filter;
    renderProducts();
  });
});
searchInput.addEventListener("input", renderProducts);
document.getElementById("year").textContent = new Date().getFullYear();
renderProducts();

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch(err => console.log("Service worker:", err));
  });
}
