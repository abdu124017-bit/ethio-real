(() => {
  const phone = '251976213646';
  const menuButton = document.getElementById('menu-toggle');
  const nav = document.getElementById('site-nav');
  menuButton.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  }));
  document.getElementById('year').textContent = new Date().getFullYear();

  let selectedFilter = 'all';
  const search = document.getElementById('product-search');
  const cards = [...document.querySelectorAll('.category-card')];
  const noResults = document.getElementById('no-results');
  function updateCards() {
    const query = search.value.trim().toLocaleLowerCase();
    let shown = 0;
    cards.forEach(card => {
      const categoryMatch = selectedFilter === 'all' || card.dataset.category === selectedFilter;
      const text = (card.innerText + ' ' + card.dataset.search).toLocaleLowerCase();
      const searchMatch = !query || text.includes(query);
      const visible = categoryMatch && searchMatch;
      card.hidden = !visible;
      if (visible) shown++;
    });
    noResults.hidden = shown > 0;
  }
  document.querySelectorAll('.filter').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach(item => item.classList.remove('active'));
    button.classList.add('active');
    selectedFilter = button.dataset.filter;
    updateCards();
  }));
  search.addEventListener('input', updateCards);
  document.querySelectorAll('.order-button').forEach(button => button.addEventListener('click', () => {
    const item = button.dataset.item;
    const message = `ሰላም ETHIO REAL። የ${item} የጅምላ ትዕዛዝ መረጃ እፈልጋለሁ። የአሁኑን ዋጋና የሚገኘውን ብዛት ይላኩልኝ።`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer');
  }));
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(() => {}));
  }
})();
