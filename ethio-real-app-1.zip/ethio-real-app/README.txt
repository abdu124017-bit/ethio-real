ETHIO REAL — GitHub Pages app files

FILES TO UPLOAD TO THE ROOT OF YOUR EXISTING GitHub repository:
- index.html
- style.css
- script.js
- manifest.json
- service-worker.js

IMPORTANT:
1. Keep your existing icon-192.png and icon-512-1.png in the repository root.
2. The website expects these image paths for the three category cover photos:
   construction/cover.jpg
   plumbing/cover.jpg
   electric/cover.jpg
   If your image names or folders are different, either rename/copy your photos to these exact paths or edit the three img src paths in index.html.
3. The WhatsApp number is set to 251976213646 (international format, no plus sign in wa.me links).
4. GitHub Pages project path is configured as /ethio-real/ in manifest.json.
5. Upload all five files together, commit the changes, then wait for GitHub Pages to publish. Open the live site and refresh it. If an old version appears, clear the browser cache or wait for the service worker cache to update.
6. The site does not show prices; it sends category-order messages to WhatsApp.
